/*
 * @Author: your name
 * @Date: 2020-01-02 13:39:42
 * @LastEditTime: 2020-01-02 13:40:15
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \vue-jsplumb\src\views\flowDeployDetail\token.js
 */
export const toke = 'eyJhbGciOiJIUzUxMiJ9.eyJDcmVhdGVkVGltZSI6MTU3Nzk0MTYzNDUyOCwibmlrZU5hbWUiOiLotoXnuqfnrqHnkIblkZgiLCJleHAiOjE1Nzc5NDUyMzQsInVzZXJJZCI6InN1cGVyLWFkbWluIn0.U-ZLjecDKKV0Hvs7xCrzH7gSS8kYrSHZnOIyuNw3mvZ1N19vIFgfVPg1Gsu5JkARKLhtV997IH2jCHqXCGUe3w'