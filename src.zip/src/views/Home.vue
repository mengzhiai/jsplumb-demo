<!--
 * @Author: your name
 * @Date: 2019-12-02 10:07:12
 * @LastEditTime: 2019-12-17 10:06:03
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \vue-jsplumb\src\views\Home.vue
 -->
<template>
  <div>
aaaa
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss" scoped>

</style>